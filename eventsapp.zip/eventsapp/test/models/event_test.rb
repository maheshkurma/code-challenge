require 'test_helper'

class EventTest < ActiveSupport::TestCase

  test "should not create event without hostname" do
    event = events(:invalid_one)
    assert_not event.save, "cannot save event without hostname"
  end
  
  test "should return all events sorted by created_at timestamp" do
     assert_equal(customers(:one).events, [events(:two), events(:one)])
  end

  test "should return all events for a host sorted by created_at timestamp" do
     assert_equal(customers(:two).events_by_host('MyString2'), [events(:five), events(:four)])
  end
end
