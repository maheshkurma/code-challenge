class Event < ActiveRecord::Base
  default_scope {order(created_at: :desc)}

  validates :desc, :hostname, presence: true
  validates :customer, presence: true 
  belongs_to :customer
end
